# resources

This is resources file for lerning courses.
